let initialized = false;

let gsap = null;
let ScrollTrigger = null;
let SplitText = null;
let TextPlugin = null;

const active = new Set();
const queue = new Map();
const completed = new Set();

const config = {
    maxActive: 25,
    maxZoom: 12,
    maxPerSection: 8,
    threshold: 0.15,
    rootMargin: "50px",
};

let observer = null;

// ------------------------
// INIT ENGINE
// ------------------------

export async function initMotionEngine(scope = document) {
    if (initialized && scope === document) return;

    // lazy load GSAP stack once
    if (!gsap) {
        const [
            gsapModule,
            scrollModule,
            splitModule,
            textModule
        ] = await Promise.all([
            import("@theme/gsap"),
            import("@theme/ScrollTrigger"),
            import("@theme/SplitText"),
            import("@theme/TextPlugin")
        ]);

        gsap = gsapModule.default || gsapModule;
        ScrollTrigger = scrollModule.default || scrollModule;

        const SplitRaw =
            splitModule.default?.SplitText ||
            splitModule.default ||
            splitModule.SplitText ||
            splitModule;

        SplitText =
            typeof SplitRaw === "function"
                ? SplitRaw
                : SplitRaw?.SplitText;

        TextPlugin = textModule.default || textModule;

        gsap.registerPlugin(
            ScrollTrigger,
            SplitText,
            TextPlugin
        );
    }

    if (!observer) {
        observer = new IntersectionObserver(onIntersect, {
            threshold: config.threshold,
            rootMargin: config.rootMargin,
        });
    }

    scope.querySelectorAll("motion-component").forEach(bind);

    initialized = true;
}

// ------------------------
// REGISTER ELEMENT
// ------------------------

export function bind(el) {
    if (completed.has(el)) return;

    const type = el.dataset.motion || "fade-up";

    queue.set(el, {
        type,
        delay: parseInt(el.dataset.motionDelay || 0) / 1000
    });

    observer.observe(el);
}

// ------------------------
// INTERSECTION HANDLER
// ------------------------

function onIntersect(entries) {
    for (const entry of entries) {
        if (!entry.isIntersecting) continue;

        const el = entry.target;
        const data = queue.get(el);

        if (!data) continue;

        if (canRun(el, data.type)) {
            run(el, data);
        }
    }
}

// ------------------------
// PERFORMANCE CONTROL
// ------------------------

function canRun(el, type) {
    if (active.size >= config.maxActive) return false;

    const isZoom = type.includes("zoom");

    if (isZoom) {
        const zoomCount = [...active].filter(a =>
            queue.get(a)?.type?.includes("zoom")
        ).length;

        if (zoomCount >= config.maxZoom) return false;
    }

    const section = el.closest("section, [class*='section']");

    if (section) {
        const count = [...active].filter(a =>
            section.contains(a)
        ).length;

        if (count >= config.maxPerSection) return false;
    }

    return true;
}

// ------------------------
// EXECUTE ANIMATION
// ------------------------

async function run(el, data) {
    active.add(el);
    observer.unobserve(el);

    try {
        await animate(el, data);
    } finally {
        active.delete(el);
        queue.delete(el);
        completed.add(el);
    }
}

// ------------------------
// GSAP ANIMATION MAP
// ------------------------

function animate(el, { type, delay }) {

    const base = {
        ease: "power3.out",
        duration: 1.2,
        delay
    };

    switch (type) {

        case "fade-up":
            gsap.set(el, { opacity: 0, y: 40 });
            return gsap.to(el, { opacity: 1, y: 0, ...base });

        case "fade-in":
            gsap.set(el, { opacity: 0 });
            return gsap.to(el, { opacity: 1, ...base });

        case "slide-left":
            gsap.set(el, { opacity: 0, x: -60 });
            return gsap.to(el, { opacity: 1, x: 0, ...base });

        case "slide-right":
            gsap.set(el, { opacity: 0, x: 60 });
            return gsap.to(el, { opacity: 1, x: 0, ...base });

        case "zoom-in":
            gsap.set(el, { opacity: 0, scale: 0.85 });
            return gsap.to(el, { opacity: 1, scale: 1, ...base });

        case "zoom-out":
            gsap.set(el, { opacity: 0, scale: 1.15 });
            return gsap.to(el, { opacity: 1, scale: 1, ...base });

        default:
            return gsap.to(el, { opacity: 1, ...base });
    }
}

// ------------------------
// PUBLIC API
// ------------------------

export function replay(el) {
    completed.delete(el);
    bind(el);
}

export function destroy() {
    observer?.disconnect();
    observer = null;

    active.clear();
    queue.clear();
    completed.clear();

    initialized = false;
}