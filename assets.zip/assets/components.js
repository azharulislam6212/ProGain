import { ShadowComponent } from "@theme/critical";
import { requestIdleCallback } from "@theme/utilities";

export function initButtons(root = document) {
  root.querySelectorAll(".btn").forEach(btn => {
    if (btn.classList.contains("is-ready")) return;
    const hasIconVariant = [...btn.classList].some(c => c.includes("btn--icon"));
    if (hasIconVariant) {
      const el = btn.querySelector(".btn__content");
      const textEl = el?.querySelector(".btn__text");
      if (!el) return;
      const iconEl = el.querySelector(".btn__icon");
      const icon = iconEl?.querySelector(".icon")?.outerHTML || "";
      btn.insertAdjacentHTML("beforeend", `
        <span class="btn__hover">
          <span class="btn__hover-circle">
            ${textEl ? `<span class="btn__hover-text">${textEl.textContent}</span>` : ""}
            ${icon ? `<span class="btn__hover-icons">
              <span class="btn__hover-icon">${icon}</span>
              <span class="btn__hover-icon">${icon}</span>
            </span>` : ""}
          </span>
        </span>
      `);
    }
    btn.classList.add("is-ready");
  });
}


 


export class Component extends ShadowComponent {
  refs = {};
  requiredRefs;
  get roots() {
    return this.shadowRoot ? [this, this.shadowRoot] : [this];
  }
  connectedCallback() {
    super.connectedCallback(),
      registerEventListeners(),
      this.#updateRefs(),
      requestIdleCallback(() => {
        for (const root of this.roots)
          this.#mutationObserver.observe(root, {
            childList: !0,
            subtree: !0,
            attributes: !0,
            attributeFilter: ["ref"],
            attributeOldValue: !0,
          });
      });
  }
  updatedCallback() {
    this.#mutationObserver.takeRecords(), this.#updateRefs();
  }
  disconnectedCallback() {
    this.#mutationObserver.disconnect();
  }
  #updateRefs() {
    const refs = {},
      elements = this.roots.reduce((acc, root) => {
        for (const element of root.querySelectorAll("[ref]")) this.#isDescendant(element) && acc.add(element);
        return acc;
      }, new Set());
    for (const ref of elements) {
      const refName = ref.getAttribute("ref") ?? "",
        isArray = refName.endsWith("[]"),
        path = isArray ? refName.slice(0, -2) : refName;
      if (isArray) {
        const array = Array.isArray(refs[path]) ? refs[path] : [];
        array.push(ref), (refs[path] = array);
      } else refs[path] = ref;
    }
    if (this.requiredRefs?.length) {
      for (const ref of this.requiredRefs) if (!(ref in refs)) throw new MissingRefError(ref, this);
    }
    this.refs = refs;
  }
  #mutationObserver = new MutationObserver((mutations) => {
    mutations.some(
      (m) =>
        (m.type === "attributes" && this.#isDescendant(m.target)) ||
        (m.type === "childList" && [...m.addedNodes, ...m.removedNodes].some(this.#isDescendant))
    ) && this.#updateRefs();
  });
  #isDescendant = (node) => getClosestComponent(getAncestor(node)) === this;
}
function getAncestor(node) {
  if (node.parentNode) return node.parentNode;
  const root = node.getRootNode();
  return root instanceof ShadowRoot ? root.host : null;
}
function getClosestComponent(node) {
  if (!node) return null;
  if (node instanceof Component || (node instanceof HTMLElement && node.tagName.toLowerCase().endsWith("-component")))
    return node;
  const ancestor = getAncestor(node);
  return ancestor ? getClosestComponent(ancestor) : null;
}
let initialized = !1;
function registerEventListeners() {
  if (initialized) return;
  initialized = !0;
  const events = ["click", "change", "select", "focus", "blur", "submit", "input", "keydown", "keyup", "toggle"],
    shouldBubble = ["focus", "blur"],
    expensiveEvents = ["pointerenter", "pointerleave"];
  for (const eventName of [...events, ...expensiveEvents]) {
    const attribute = `on:${eventName}`;
    document.addEventListener(
      eventName,
      (event) => {
        const element = getElement(event);
        if (!element) return;
        const proxiedEvent =
          event.target !== element
            ? new Proxy(event, {
              get(target, property) {
                if (property === "target") return element;
                const value2 = Reflect.get(target, property);
                return typeof value2 == "function" ? value2.bind(target) : value2;
              },
            })
            : event,
          value = element.getAttribute(attribute) ?? "";
        let [selector, method] = value.split("/");
        const matches = value.match(/([\/\?][^\/\?]+)([\/\?][^\/\?]+)$/),
          data = matches ? matches[2] : null,
          instance = selector
            ? selector.startsWith("#")
              ? document.querySelector(selector)
              : element.closest(selector)
            : getClosestComponent(element);
        if (!(instance instanceof Component) || !method) return;
        method = method.replace(/\?.*/, "");
        const callback = instance[method];
        if (typeof callback == "function")
          try {
            const args = [proxiedEvent];
            data && args.unshift(parseData(data)), callback.call(instance, ...args);
          } catch (error) {
            console.error(error);
          }
      },
      { capture: !0 }
    );
  }
  function getElement(event) {
    const target = event.composedPath?.()[0] ?? event.target;
    if (target instanceof Element)
      return target.hasAttribute(`on:${event.type}`)
        ? target
        : expensiveEvents.includes(event.type)
          ? null
          : event.bubbles || shouldBubble.includes(event.type)
            ? target.closest(`[on\\:${event.type}]`)
            : null;
  }
}
function parseData(str) {
  const delimiter = str[0],
    data = str.slice(1);
  return delimiter === "?"
    ? Object.fromEntries(
      Array.from(new URLSearchParams(data).entries()).map(([key, value]) => [key, parseValue(value)])
    )
    : parseValue(data);
}
function parseValue(str) {
  if (str === "true") return !0;
  if (str === "false") return !1;
  const maybeNumber = Number(str);
  return !isNaN(maybeNumber) && str.trim() !== "" ? maybeNumber : str;
}
class MissingRefError extends Error {
  constructor(ref, component) {
    super(`Required ref "${ref}" not found in component ${component.tagName.toLowerCase()}`);
  }
}
