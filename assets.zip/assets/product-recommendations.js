class ProductRecommendations extends HTMLElement {
    #intersectionObserver = new IntersectionObserver(
        (entries, observer) => {
            entries[0]?.isIntersecting && (observer.disconnect(), this.#loadRecommendations());
        },
        { rootMargin: "0px 0px 400px 0px" }
    );
    #mutationObserver = new MutationObserver((mutations) => {
        for (const mutation of mutations)
            if (
                !(mutation.target !== this || mutation.type !== "attributes") &&
                mutation.attributeName !== "data-error" &&
                !(mutation.attributeName === "class" && this.classList.contains("hidden")) &&
                !(
                    mutation.attributeName === "data-recommendations-performed" &&
                    this.dataset.recommendationsPerformed === "true"
                )
            ) {
                this.#loadRecommendations();
                break;
            }
    });
    #cachedRecommendations = {};
    #activeFetch = null;
    connectedCallback() {
        this.#intersectionObserver.observe(this), this.#mutationObserver.observe(this, { attributes: !0 });
    }
    #loadRecommendations() {
        const { productId, recommendationsPerformed, sectionId, intent, useManualProducts } = this.dataset,
            id = this.id;
        if (!productId || !id) throw new Error("Product ID and an ID attribute are required");
        useManualProducts !== "true" &&
            recommendationsPerformed !== "true" &&
            this.#fetchCachedRecommendations(productId, sectionId, intent)
                .then((result) => {
                    if (!result.success) {
                        Shopify.designMode || this.#handleError(new Error(`Server returned ${result.status}`));
                        return;
                    }
                    const html = document.createElement("div");
                    html.innerHTML = result.data || "";
                    const recommendations = html.querySelector(`product-recommendations[id="${id}"]`);
                    recommendations?.innerHTML && recommendations.innerHTML.trim().length
                        ? ((this.dataset.recommendationsPerformed = "true"),
                          (this.innerHTML = recommendations.innerHTML))
                        : this.#handleError(new Error("No recommendations available"));
                })
                .catch((e) => {
                    this.#handleError(e);
                });
    }
    async #fetchCachedRecommendations(productId, sectionId, intent) {
        const url = `${this.dataset.url}&product_id=${productId}&section_id=${sectionId}&intent=${intent}`;
        if (!Shopify.designMode) {
            const cachedResponse = this.#cachedRecommendations[url];
            if (cachedResponse) return { success: !0, data: cachedResponse };
        }
        this.#activeFetch?.abort(), (this.#activeFetch = new AbortController());
        try {
            const response = await fetch(url, { signal: this.#activeFetch.signal });
            if (!response.ok) return { success: !1, status: response.status };
            const text = await response.text();
            return Shopify.designMode || (this.#cachedRecommendations[url] = text), { success: !0, data: text };
        } finally {
            this.#activeFetch = null;
        }
    }
    #handleError(error) {
        console.error("Product recommendations error:", error.message),
            this.classList.add("hidden"),
            (this.dataset.error = "Error loading product recommendations");
    }
}
customElements.get("product-recommendations") ||
    customElements.define("product-recommendations", ProductRecommendations);
//# sourceMappingURL=/cdn/shop/t/17/assets/product-recommendations.js.map?v=183989179744892943431772247681
